import React, { useEffect } from "react";
import NavBar from "./Components/NavBar";
import Notification from "./Components/Notification";
import { Outlet } from "react-router-dom";
import { useDispatch, useSelector } from "react-redux";
import { isCurrentUser } from "./utility/UserSLice";
  
const App = () => { 
  const dispatch = useDispatch();
  const { isAuthLoading } = useSelector((state) => state.users);
  useEffect(() => {
    dispatch(isCurrentUser());
  }, [dispatch]);

  return (
    <div>
      <Notification />
      <NavBar />
      <Outlet />
    </div>
  );
};
export default App;
