import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import { useSelector } from "react-redux";
import { IoIosHome } from "react-icons/io";
import { MdOutlineAdminPanelSettings } from "react-icons/md";
import { TiShoppingCart } from "react-icons/ti";
import { FaRegHeart } from "react-icons/fa6";
import { FiUser, FiSearch } from "react-icons/fi";
import {getAllProducts} from "../utility/ProductSlice.js";
const NavBar = () => {
  const navigate = useNavigate();
  const { user } = useSelector((state) => state.users);
  const [searchTerm, setSearchTerm] = useState("");
const {productList} = useSelector((state) => state.products);
 
const handleSearch = (e) => {
  e.preventDefault();

  const safeSearchTerm = (searchTerm || "").trim().toLowerCase();
  if (!safeSearchTerm) return;

  const filteredResults = productList.filter((item) => {
    const titleMatch = item.title?.toLowerCase().includes(safeSearchTerm);
    const categoryMatch = item.category?.toLowerCase().includes(safeSearchTerm);
    
    return titleMatch || categoryMatch;
  });

  navigate('/search', { state: { results: filteredResults, searchTerm: safeSearchTerm } });
  setSearchTerm("");
};
  return (
    <nav className="w-full bg-white border-b border-zinc-200 sticky top-0 z-50">
      <div className="max-w-[1200px] mx-auto px-6 h-20 flex justify-between items-center">
        {/* Left Side: Logo */}
        <div 
          onClick={() => navigate("/")}
          className="cursor-pointer text-2xl font-extrabold tracking-tighter text-zinc-900 flex-shrink-0"
        >
          Navazon
        </div>

        {/* Center: Search Bar */}
        <form onSubmit={handleSearch} className="relative w-full max-w-md mx-4 hidden md:block">
          <FiSearch className="absolute left-3 top-1/2 -translate-y-1/2 text-zinc-400" size={18} />
          <input
            type="text"
            placeholder="Search products..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full px-4 py-2 pl-10 pr-10 bg-zinc-50 border border-zinc-300 rounded-none text-sm text-zinc-900 focus:outline-none focus:bg-white focus:border-zinc-900 focus:ring-0 transition-colors placeholder:text-zinc-400"
          /> 
          <button type="submit" className="absolute right-3 top-1/2 -translate-y-1/2 text-zinc-400 hover:text-zinc-700 transition-colors focus:outline-none">
            <FiSearch size={18} />
          </button>
        </form>

        {/* Right Side: Icons */}
        <div className="flex items-center gap-6 sm:gap-8">
          
          {/* Home */}
          <button 
            onClick={() => navigate("/")}
            className="group relative flex items-center justify-center text-zinc-500 hover:text-purple-600 transition-colors focus:outline-none"
          >
            <IoIosHome size={22} />
            <span className="absolute left-1/2 -translate-x-1/2 top-full mt-3 bg-zinc-800 text-white text-xs font-semibold px-3 py-1.5 opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none whitespace-nowrap z-50 rounded-none shadow-md">
              Home
            </span>
          </button>

          {/* Admin */}
          <button 
            onClick={() => navigate("/Admin")}
            className="group relative flex items-center justify-center text-zinc-500 hover:text-purple-600 transition-colors focus:outline-none"
          >
            <MdOutlineAdminPanelSettings size={24} />
            <span className="absolute left-1/2 -translate-x-1/2 top-full mt-3 bg-zinc-800 text-white text-xs font-semibold px-3 py-1.5 opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none whitespace-nowrap z-50 rounded-none shadow-md">
              Admin
            </span>
          </button>

          {/* Wishlist */}
          <button 
            onClick={() => navigate("/wishlist")}
            className="group relative flex items-center justify-center text-zinc-500 hover:text-purple-600 transition-colors focus:outline-none"
          >
            <FaRegHeart size={20} />
            <span className="absolute left-1/2 -translate-x-1/2 top-full mt-3 bg-zinc-800 text-white text-xs font-semibold px-3 py-1.5 opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none whitespace-nowrap z-50 rounded-none shadow-md">
              Wishlist
            </span>
          </button>

          {/* Cart */}
          <button 
            onClick={() => navigate("/addtocart")}
            className="group relative flex items-center justify-center text-zinc-500 hover:text-purple-600 transition-colors focus:outline-none"
          >
            <div className="relative">
              <TiShoppingCart size={26} />
              {user?.Cart?.length > 0 && (
                <span className="absolute -top-1.5 -right-2 bg-purple-600 text-white text-[9px] font-bold px-1.5 py-0.5 rounded-none flex items-center justify-center min-w-[16px] shadow-sm">
                  {user.Cart.length}
                </span>
              )}
            </div>
            <span className="absolute left-1/2 -translate-x-1/2 top-full mt-3 bg-zinc-800 text-white text-xs font-semibold px-3 py-1.5 opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none whitespace-nowrap z-50 rounded-none shadow-md">
              Cart
            </span>
          </button>

          {/* Profile */}
          <button 
            onClick={() => navigate(user?.name ? "/profile" : "/login")}
            className="group relative flex items-center justify-center text-zinc-500 hover:text-purple-600 transition-colors focus:outline-none"
          >
            <FiUser size={22} />
            <span className="absolute left-1/2 -translate-x-1/2 top-full mt-3 bg-zinc-800 text-white text-xs font-semibold px-3 py-1.5 opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none whitespace-nowrap z-50 rounded-none shadow-md">
              Profile
            </span>
          </button>

        </div>
      </div>
    </nav>
  );
};

export default NavBar;
